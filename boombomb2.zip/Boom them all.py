import os
import pygame
import random

pygame.init()

size = width, height = 600, 600
screen = pygame.display.set_mode(size)


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as message:
        print('Не удалось загрузить изображение:', name)
        raise SystemExit(message)

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


all_sprites = pygame.sprite.Group()
sprite = pygame.sprite.Sprite()
sprite.image = load_image("bomb2.png")
sprite.rect = sprite.image.get_rect()
all_sprites.add(sprite)


class Bomb2(pygame.sprite.Sprite):
    image = load_image("bomb2.png", color_key=-1)
    image_boom = load_image("boom.png", color_key=-1)

    def __init__(self, *group):
        super().__init__(*group)
        self.image = Bomb2.image
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(width - 100)
        self.rect.y = random.randrange(height - 100)

    def update(self, *args):
        if args and args[0].type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(args[0].pos):
            self.image = self.image_boom


class Boom(pygame.sprite.Sprite):
    image = load_image("boom.png", color_key=-1)

    def __init__(self, pos):
        super().__init__(all_sprites)
        self.image = Boom.image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]


bomb2 = Bomb2()
for _ in range(20):
    Bomb2(all_sprites)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            # Boom(event.pos)
            bomb2.update(event)
    screen.fill(pygame.Color((0, 0, 0)))
    all_sprites.draw(screen)
    all_sprites.update(event)
    pygame.display.flip()
pygame.quit()
